
$(function(){
// Cycle

    if ( $.fn.cycle ){
        $(".l-slideshow").each(function(index, item){
            $(item).cycle({
                // fx: "scrollHorz",
                speed: 300,
                timeout: 0,
                slides: "> li",
                log: false,
                prev: $(item).siblings(".prev"),
                next: $(item).siblings(".next")
            });
        });
    }



});